﻿using itvidpradotnetcoreadvanced.Models;

namespace itvidpradotnetcoreadvanced.Models
{
    public class AuthorizeAttributes
    {
        //private readonly LoginContext _loginContext;
        //public AuthorizeAttributes(LoginContext loginContext)
        //{
        //    _loginContext = loginContext;
        //}

        //public bool IsAdmin(string username , string password)
        //{
        //    return _loginContext.Users.Any(a.username == UserName);
        //}
    }
}
