﻿namespace itvidpradotnetcoreadvanced.Models.CSharpModels
{
    public class Datatype
    {
        public string Content { get; set; }
    }
}
