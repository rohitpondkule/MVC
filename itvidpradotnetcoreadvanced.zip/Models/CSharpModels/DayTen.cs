﻿namespace itvidpradotnetcoreadvanced.Models.CSharpModels
{
    public class DayTen
    {
        public string Content { get; set; }
    }
}
