﻿namespace itvidpradotnetcoreadvanced.Models.CSharpModels.Constants
{
    public class DaySeven
    {
        public string Content { get; set; }
    }
}
