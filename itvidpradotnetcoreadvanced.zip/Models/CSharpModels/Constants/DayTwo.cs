﻿namespace itvidpradotnetcoreadvanced.Models.CSharpModels.Constants
{
    public class DayTwo
    {
        public string Content { get; set; }
    }
}
