﻿namespace itvidpradotnetcoreadvanced.Models.CSharpModels.Constants
{
    public class DayFour
    {
        public string Content { get; set; }
    }
}
