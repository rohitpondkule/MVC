﻿namespace itvidpradotnetcoreadvanced.Services.CSharpServices
{
    public interface IFileReaderService
    {
        string ReadContent(string fileName);
    }
}
